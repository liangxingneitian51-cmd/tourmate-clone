export default function Home() {
  return (
    <main style={{fontFamily:"sans-serif",padding:"40px"}}>
      <h1>TourMate Clone</h1>
      <p>サイトが正常に表示されています。</p>
      <button style={{padding:"10px 20px",fontSize:"16px"}}>
        ガイドとして参加
      </button>
    </main>
  );
}