export default {
  reactStrictMode: true,
};