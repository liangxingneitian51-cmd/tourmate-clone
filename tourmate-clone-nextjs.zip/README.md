# TourMate (clone)

あなたの送ってくれた TourMate のリンクを「雰囲気だけ模倣」して Next.js で作り直したMVPです。
主目的は「ガイドとして参加」5ステップフォームで、未入力なら次へ進めない＆先のステップに飛べない、を実装すること。

## Run
```bash
npm i
npm run dev
```
open http://localhost:3000

## Where to edit
- 5ステップの必須ルール: `lib/validation.ts`
- フォームUI: `app/guide/apply/page.tsx`
- サーバー側検証(API): `app/api/guide-apply/route.ts`

## Deploy (free)
Vercelにそのまま載せられます。
