import { NextResponse } from "next/server";
import { validateAll, type GuideForm } from "@/lib/validation";

export async function POST(req: Request) {
  const body = (await req.json()) as GuideForm;

  const errors = validateAll(body);
  if (Object.keys(errors).length > 0) {
    return NextResponse.json({ ok: false, errors }, { status: 400 });
  }

  // In real app: store in DB, send to Slack, email, etc.
  return NextResponse.json({ ok: true });
}
