import Link from "next/link";

export default function Home() {
  return (
    <main>
      <section className="hero">
        <div className="container heroGrid">
          <div>
            <h1 className="hTitle">TourMate</h1>
            <p className="hSub">
              「現地の人とつながる」旅行体験を、もっと簡単に。旅行者はローカルガイドを見つけ、
              ガイドは自分のスキルで収益化できる——そんなMVPのクローンです。
            </p>

            <div className="ctaRow">
              <Link className="btn btnPrimary" href="/guide/apply">ガイドとして参加 →</Link>
              <Link className="btn" href="/traveler">旅行者として使う →</Link>
            </div>

            <div className="badges">
              <span className="badge">5ステップ応募フォーム</span>
              <span className="badge">入力しないと次に進めない</span>
              <span className="badge">先のステップに飛べない</span>
              <span className="badge">サーバー側も再検証</span>
            </div>
          </div>

          <div className="card">
            <h3>まずはここを作り込み</h3>
            <p>
              ①ガイド応募の離脱を減らす<br/>
              ②情報を揃える（必須入力）<br/>
              ③審査/マッチングが楽になる
            </p>
            <div className="hr" />
            <p className="note">
              ※ デザインは「雰囲気模倣」用のテンプレ。色や文言はいつでも変更できます。
            </p>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <h2 className="sectionTitle">できること（MVP）</h2>
          <div className="cardGrid">
            <div className="card">
              <h3>旅行者</h3>
              <p>希望エリア/言語/目的を入力して、ガイドとマッチングする前提の導線。</p>
            </div>
            <div className="card">
              <h3>ガイド</h3>
              <p>5ステップ応募。未入力なら進めない＋先ステップへジャンプ不可。</p>
            </div>
            <div className="card">
              <h3>運用</h3>
              <p>最終送信時にサーバー側でも必須・形式を再チェック（改ざん対策）。</p>
            </div>
          </div>

          <div className="section" />
          <div className="kpiRow">
            <div className="kpi">
              <div className="n">5</div>
              <div className="l">応募ステップ</div>
            </div>
            <div className="kpi">
              <div className="n">0</div>
              <div className="l">未入力での遷移</div>
            </div>
            <div className="kpi">
              <div className="n">2</div>
              <div className="l">クライアント/サーバー二重検証</div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
