"use client";

import { useMemo, useState } from "react";
import { type Errors, type GuideForm, validateStep } from "@/lib/validation";

const steps = [
  { id: 1, label: "基本情報" },
  { id: 2, label: "言語・エリア" },
  { id: 3, label: "料金・稼働" },
  { id: 4, label: "自己紹介" },
  { id: 5, label: "確認" },
];

const langOptions = ["English", "中文", "한국어", "Español", "Français", "Deutsch"];

export default function GuideApply() {
  const [current, setCurrent] = useState(1);
  const [completed, setCompleted] = useState(0);
  const [errors, setErrors] = useState<Errors>({});
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);

  const [data, setData] = useState<GuideForm>({
    displayName: "",
    email: "",
    phone: "",

    baseArea: "",
    languages: [],
    guideType: "",

    hourlyRateJPY: "",
    availability: "",
    canMeetOnline: false,

    bio: "",
    experience: "",
    socials: "",

    agreeToTerms: false,
  });

  const stepAllowedMax = useMemo(() => completed + 1, [completed]);

  function go(step: number) {
    if (step <= stepAllowedMax) setCurrent(step);
  }

  function set<K extends keyof GuideForm>(key: K, val: GuideForm[K]) {
    setData((d) => ({ ...d, [key]: val }));
  }

  function toggleLang(l: string) {
    setData((d) => {
      const has = d.languages.includes(l);
      return { ...d, languages: has ? d.languages.filter((x) => x !== l) : [...d.languages, l] };
    });
  }

  function next() {
    const e = validateStep(current, data);
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    setCompleted((c) => Math.max(c, current));
    setCurrent((s) => Math.min(5, s + 1));
  }

  function back() {
    setErrors({});
    setCurrent((s) => Math.max(1, s - 1));
  }

  async function submit() {
    const e = validateStep(5, data);
    setErrors(e);
    if (Object.keys(e).length > 0) return;

    setSubmitting(true);
    try {
      const res = await fetch("/api/guide-apply", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });

      if (!res.ok) {
        const payload = await res.json().catch(() => ({}));
        setErrors(payload.errors ?? { agreeToTerms: "送信に失敗しました" });
        return;
      }
      setDone(true);
    } finally {
      setSubmitting(false);
    }
  }

  if (done) {
    return (
      <main className="page">
        <div className="container">
          <h1 className="h1">応募を受け付けました</h1>
          <p className="lead">
            ありがとうございます。審査/連絡フローは次の開発で追加できます（メール通知、管理画面など）。
          </p>
          <div className="card">
            <h3>送信内容（ダイジェスト）</h3>
            <p className="note">
              表示名：{data.displayName}<br/>
              エリア：{data.baseArea}<br/>
              言語：{data.languages.join(", ") || "-"}<br/>
              種類：{data.guideType || "-"}<br/>
              目安：¥{data.hourlyRateJPY}/h
            </p>
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="page">
      <div className="container wizard">
        <h1 className="h1">ガイドとして参加</h1>
        <p className="lead">
          5ステップ応募フォーム。<b>入力が不十分だと次に進めません</b>。
          また、完了していない先ステップへのジャンプも不可です。
        </p>

        <div className="stepper" role="tablist" aria-label="ステップ">
          {steps.map((s) => {
            const isActive = s.id === current;
            const isDone = s.id <= completed;
            const isDisabled = s.id > stepAllowedMax;
            const cls = [
              "step",
              isActive ? "stepActive" : "",
              isDone ? "stepDone" : "",
              isDisabled ? "stepDisabled" : "",
            ].join(" ");
            return (
              <button
                key={s.id}
                className={cls}
                onClick={() => go(s.id)}
                disabled={isDisabled}
                type="button"
              >
                {s.id}. {s.label}
              </button>
            );
          })}
        </div>

        <div className="form">
          {current === 1 && (
            <>
              <div className="row">
                <div className="field">
                  <div className="label">表示名（必須）</div>
                  <input className="input" value={data.displayName} onChange={(e) => set("displayName", e.target.value)} />
                  {errors.displayName && <div className="error">{errors.displayName}</div>}
                </div>
                <div className="field">
                  <div className="label">メール（必須）</div>
                  <input className="input" value={data.email} onChange={(e) => set("email", e.target.value)} />
                  {errors.email && <div className="error">{errors.email}</div>}
                </div>
              </div>

              <div className="field">
                <div className="label">電話番号（必須）</div>
                <input className="input" value={data.phone} onChange={(e) => set("phone", e.target.value)} />
                {errors.phone && <div className="error">{errors.phone}</div>}
              </div>

              <div className="pill">ヒント：ここは「連絡用」なので、空欄だと次へ進めないようにしています</div>
            </>
          )}

          {current === 2 && (
            <>
              <div className="field">
                <div className="label">主な活動エリア（必須）</div>
                <input className="input" placeholder="例）Tokyo / Shinjuku / Asakusa" value={data.baseArea} onChange={(e) => set("baseArea", e.target.value)} />
                {errors.baseArea && <div className="error">{errors.baseArea}</div>}
              </div>

              <div className="field">
                <div className="label">対応言語（必須・複数可）</div>
                <div className="row">
                  {langOptions.map((l) => (
                    <label key={l} className="pill" style={{cursor:"pointer"}}>
                      <input
                        type="checkbox"
                        checked={data.languages.includes(l)}
                        onChange={() => toggleLang(l)}
                      />
                      {l}
                    </label>
                  ))}
                </div>
                {errors.languages && <div className="error">{errors.languages}</div>}
              </div>

              <div className="field">
                <div className="label">ガイド種類（必須）</div>
                <select className="select" value={data.guideType} onChange={(e) => set("guideType", e.target.value as any)}>
                  <option value="">選択してください</option>
                  <option value="city">街歩き</option>
                  <option value="food">グルメ</option>
                  <option value="history">歴史</option>
                  <option value="nightlife">ナイトライフ</option>
                  <option value="nature">自然</option>
                </select>
                {errors.guideType && <div className="error">{errors.guideType}</div>}
              </div>
            </>
          )}

          {current === 3 && (
            <>
              <div className="row">
                <div className="field">
                  <div className="label">時給（目安・JPY）（必須）</div>
                  <input className="input" inputMode="numeric" placeholder="例）3000" value={data.hourlyRateJPY} onChange={(e) => set("hourlyRateJPY", e.target.value)} />
                  {errors.hourlyRateJPY && <div className="error">{errors.hourlyRateJPY}</div>}
                </div>
                <div className="field">
                  <div className="label">オンライン対応</div>
                  <label className="pill" style={{cursor:"pointer"}}>
                    <input type="checkbox" checked={data.canMeetOnline} onChange={(e) => set("canMeetOnline", e.target.checked)} />
                    オンラインでも案内できる
                  </label>
                </div>
              </div>

              <div className="field">
                <div className="label">稼働可能な曜日・時間（必須）</div>
                <textarea className="textarea" placeholder="例）平日18-22 / 土日終日 / 週3回など" value={data.availability} onChange={(e) => set("availability", e.target.value)} />
                {errors.availability && <div className="error">{errors.availability}</div>}
              </div>
            </>
          )}

          {current === 4 && (
            <>
              <div className="field">
                <div className="label">自己紹介（必須・80文字以上）</div>
                <textarea className="textarea" placeholder="どんな案内ができるか、強み、どんな旅行者に合うかなど" value={data.bio} onChange={(e) => set("bio", e.target.value)} />
                <div className="small">{data.bio.trim().length} / 80</div>
                {errors.bio && <div className="error">{errors.bio}</div>}
              </div>

              <div className="field">
                <div className="label">経験（必須）</div>
                <textarea className="textarea" placeholder="例）留学、接客、通訳、観光案内、英語学習歴など" value={data.experience} onChange={(e) => set("experience", e.target.value)} />
                {errors.experience && <div className="error">{errors.experience}</div>}
              </div>

              <div className="field">
                <div className="label">SNS/ポートフォリオ（任意）</div>
                <input className="input" placeholder="例）Instagram / X / Website" value={data.socials} onChange={(e) => set("socials", e.target.value)} />
              </div>
            </>
          )}

          {current === 5 && (
            <>
              <div className="card" style={{marginBottom:12}}>
                <h3>確認</h3>
                <p className="note">
                  表示名：{data.displayName || "-"}<br/>
                  メール：{data.email || "-"}<br/>
                  電話：{data.phone || "-"}<br/>
                  エリア：{data.baseArea || "-"}<br/>
                  言語：{data.languages.join(", ") || "-"}<br/>
                  種類：{data.guideType || "-"}<br/>
                  目安：¥{data.hourlyRateJPY || "-"} / h<br/>
                  オンライン：{data.canMeetOnline ? "可" : "不可"}<br/>
                </p>
              </div>

              <label className="pill" style={{cursor:"pointer"}}>
                <input
                  type="checkbox"
                  checked={data.agreeToTerms}
                  onChange={(e) => set("agreeToTerms", e.target.checked)}
                />
                規約に同意します（必須）
              </label>
              {errors.agreeToTerms && <div className="error" style={{marginTop:6}}>{errors.agreeToTerms}</div>}

              <div className="hr" />
              <p className="note">
                ※ 送信時はサーバー側でも必須/形式チェックを再実行します（不正送信対策）。
              </p>
            </>
          )}

          <div className="actions">
            <button className="btn" onClick={back} disabled={current === 1 || submitting} type="button">
              戻る
            </button>

            {current < 5 ? (
              <button className="btn btnPrimary" onClick={next} disabled={submitting} type="button">
                次へ →
              </button>
            ) : (
              <button className="btn btnPrimary" onClick={submit} disabled={submitting} type="button">
                {submitting ? "送信中…" : "送信"}
              </button>
            )}
          </div>
        </div>
      </div>
    </main>
  );
}
