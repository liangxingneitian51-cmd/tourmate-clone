import Link from "next/link";

export default function Traveler(){
  return (
    <main className="page">
      <div className="container">
        <h1 className="h1">旅行者として使う</h1>
        <p className="lead">
          ここは旅行者向け導線のダミーです。次の開発で「ガイド検索/問い合わせ」へ拡張できます。
        </p>

        <div className="cardGrid">
          <div className="card">
            <h3>例：行きたいエリア</h3>
            <p>Shinjuku / Asakusa / Kyoto / Osaka …</p>
          </div>
          <div className="card">
            <h3>例：言語</h3>
            <p>English / Chinese / Korean …</p>
          </div>
          <div className="card">
            <h3>例：目的</h3>
            <p>Food / Nightlife / History / Anime …</p>
          </div>
        </div>

        <div className="section" />
        <Link className="btn btnPrimary" href="/guide/apply">ガイド応募フォームを見る →</Link>
      </div>
    </main>
  );
}
