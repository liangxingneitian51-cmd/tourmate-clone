export default function Page(){
  return (
    <main className="page">
      <div className="container">
        <h1 className="h1">Terms</h1>
        <p className="lead">ここはダミーページです。必要なら文章を入れていきましょう。</p>
      </div>
    </main>
  );
}
