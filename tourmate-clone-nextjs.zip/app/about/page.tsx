export default function About(){
  return (
    <main className="page">
      <div className="container">
        <h1 className="h1">About</h1>
        <p className="lead">
          これは、あなたが送ってくれたTourMateのリンクを「雰囲気だけ模倣」して、
          Next.jsで作り直したクローン（MVP）です。ガイド応募の5ステップ入力制御が主目的。
        </p>
        <div className="card">
          <h3>次に足せるもの</h3>
          <p className="note">
            ・画像アップロード（身分証/プロフィール）<br/>
            ・審査フロー（管理画面）<br/>
            ・ガイド検索/マッチング<br/>
            ・決済（Stripe）<br/>
            ・多言語（EN/JP）
          </p>
        </div>
      </div>
    </main>
  );
}
