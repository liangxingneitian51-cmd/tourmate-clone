export type GuideForm = {
  // step1
  displayName: string;
  email: string;
  phone: string;

  // step2
  baseArea: string;
  languages: string[]; // ["English", ...]
  guideType: "city" | "food" | "history" | "nightlife" | "nature" | "";

  // step3
  hourlyRateJPY: string; // keep string for input
  availability: string; // free text
  canMeetOnline: boolean;

  // step4
  bio: string;
  experience: string;
  socials: string;

  // step5
  agreeToTerms: boolean;
};

export type Errors = Partial<Record<keyof GuideForm, string>>;

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function validateStep(step: number, data: GuideForm): Errors {
  const e: Errors = {};

  if (step === 1) {
    if (!data.displayName.trim()) e.displayName = "表示名は必須です";
    if (!emailRe.test(data.email.trim())) e.email = "メール形式が正しくありません";
    if (!data.phone.trim()) e.phone = "電話番号は必須です";
  }

  if (step === 2) {
    if (!data.baseArea.trim()) e.baseArea = "活動エリアは必須です";
    if (!data.languages.length) e.languages = "対応言語を1つ以上選んでください";
    if (!data.guideType) e.guideType = "ガイド種類を選んでください";
  }

  if (step === 3) {
    const n = Number(data.hourlyRateJPY);
    if (!data.hourlyRateJPY.trim()) e.hourlyRateJPY = "時給（目安）は必須です";
    else if (!Number.isFinite(n) || n <= 0) e.hourlyRateJPY = "正しい数値を入力してください";
    if (!data.availability.trim()) e.availability = "稼働可能な曜日/時間を入力してください";
  }

  if (step === 4) {
    if (data.bio.trim().length < 80) e.bio = "自己紹介は80文字以上でお願いします";
    if (!data.experience.trim()) e.experience = "経験（観光/接客/語学など）を入力してください";
  }

  if (step === 5) {
    if (!data.agreeToTerms) e.agreeToTerms = "規約に同意してください";
  }

  return e;
}

export function validateAll(data: GuideForm): Errors {
  // run all step validations
  const merged: Errors = {};
  for (let s = 1; s <= 5; s++) Object.assign(merged, validateStep(s, data));
  return merged;
}
