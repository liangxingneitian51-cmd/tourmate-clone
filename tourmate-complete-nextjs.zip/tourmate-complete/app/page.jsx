export default function Home() {
  return (
    <>
      <div className="h1">Let&apos;s build something new</div>
      <p className="p">
        これは TourMate のクローン用デモです。まずは「ガイドとして参加」からオンボーディング（5ステップ）を進めてください。
      </p>

      <div className="grid">
        <div className="card">
          <h2 style={{ marginTop: 0 }}>できること</h2>
          <ul className="p" style={{ marginTop: 8 }}>
            <li>5ステップのガイド登録フォーム</li>
            <li>入力チェック（必須／形式）</li>
            <li>完了後に内容の確認画面</li>
          </ul>
          <div className="row" style={{ marginTop: 12 }}>
            <a className="btn" href="/guide">ガイドとして参加</a>
            <a className="btn secondary" href="/api/health">ヘルスチェック</a>
          </div>
        </div>

        <div className="card">
          <div className="badge">Tip</div>
          <p className="p" style={{ marginTop: 10 }}>
            Vercel でデプロイする場合は、GitHub のリポジトリ直下に <b>package.json</b> と <b>app/</b> がある状態で push してください。
          </p>
          <div className="code" style={{ marginTop: 10 }}>
            npm install\n
            npm run dev
          </div>
        </div>
      </div>
    </>
  );
}
