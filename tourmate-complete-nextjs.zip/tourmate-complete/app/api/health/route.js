export async function GET() {
  return Response.json({ ok: true, name: 'tourmate-clone', ts: Date.now() });
}
