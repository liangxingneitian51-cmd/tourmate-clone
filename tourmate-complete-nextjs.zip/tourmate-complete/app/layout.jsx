import './globals.css';

export const metadata = {
  title: 'TourMate Clone',
  description: 'TourMate clone web app'
};

export default function RootLayout({ children }) {
  return (
    <html lang="ja">
      <body>
        <header className="header">
          <div className="brand">TourMate</div>
          <nav className="nav">
            <a href="/">Home</a>
            <a href="/guide">ガイドとして参加</a>
            <a href="#" aria-disabled="true" className="muted">Login</a>
            <a href="#" aria-disabled="true" className="muted">Sign Up</a>
          </nav>
        </header>
        <main className="container">{children}</main>
        <footer className="footer">© {new Date().getFullYear()} TourMate (clone)</footer>
      </body>
    </html>
  );
}
