'use client';

import { useMemo, useState } from 'react';

const initial = {
  name: '',
  email: '',
  phone: '',
  city: 'Tokyo',
  languages: ['Japanese'],
  categories: [],
  years: '1',
  bio: '',
  rate: '5000',
  availability: 'Weekends',
};

function isEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

function isPhone(v) {
  // loose JP-friendly: digits, +, -, spaces
  return /^[0-9+\-\s]{8,}$/.test(v);
}

const CATEGORY_OPTIONS = ['Food', 'Culture', 'Nature', 'Nightlife', 'Shopping'];
const LANG_OPTIONS = ['Japanese', 'English', 'Chinese', 'Korean'];

export default function GuideOnboarding() {
  const [step, setStep] = useState(1);
  const [data, setData] = useState(initial);
  const [touched, setTouched] = useState({});

  const errors = useMemo(() => {
    const e = {};

    if (!data.name.trim()) e.name = '名前は必須です';
    if (!data.email.trim()) e.email = 'メールは必須です';
    else if (!isEmail(data.email)) e.email = 'メール形式が正しくありません';

    if (!data.phone.trim()) e.phone = '電話番号は必須です';
    else if (!isPhone(data.phone)) e.phone = '電話番号の形式が正しくありません';

    if (!data.city.trim()) e.city = '都市は必須です';

    if (!data.languages?.length) e.languages = '言語を1つ以上選んでください';
    if (!data.categories?.length) e.categories = 'カテゴリーを1つ以上選んでください';

    if (!String(data.years).trim()) e.years = '経験年数は必須です';

    if (!data.bio.trim()) e.bio = '自己紹介は必須です';
    else if (data.bio.trim().length < 50) e.bio = '自己紹介は50文字以上が目安です';

    const rateNum = Number(data.rate);
    if (!data.rate.trim()) e.rate = '料金は必須です';
    else if (!Number.isFinite(rateNum) || rateNum <= 0) e.rate = '料金は正の数で入力してください';

    if (!data.availability.trim()) e.availability = '稼働日は必須です';

    return e;
  }, [data]);

  function mark(name) {
    setTouched((t) => ({ ...t, [name]: true }));
  }

  function canNext() {
    if (step === 1) return !errors.name && !errors.email && !errors.phone;
    if (step === 2) return !errors.city && !errors.languages && !errors.categories;
    if (step === 3) return !errors.years && !errors.bio;
    if (step === 4) return !errors.rate && !errors.availability;
    return true;
  }

  function next() {
    if (!canNext()) return;
    setStep((s) => Math.min(5, s + 1));
  }

  function back() {
    setStep((s) => Math.max(1, s - 1));
  }

  function toggleArray(key, value) {
    setData((d) => {
      const arr = new Set(d[key] || []);
      if (arr.has(value)) arr.delete(value);
      else arr.add(value);
      return { ...d, [key]: Array.from(arr) };
    });
    mark(key);
  }

  function reset() {
    setData(initial);
    setTouched({});
    setStep(1);
  }

  return (
    <div className="card" style={{ background: 'white' }}>
      <div className="badge">Guide Onboarding</div>
      <h1 style={{ margin: '10px 0 6px' }}>ガイド登録（5ステップ）</h1>
      <p className="p" style={{ marginTop: 0 }}>
        入力が揃うと次へ進めます。最後に内容を確認して完了です。
      </p>

      <div className="stepper" aria-label="progress">
        {[1, 2, 3, 4, 5].map((n) => (
          <div key={n} className={`dot ${n === step ? 'active' : ''}`} title={`step ${n}`} />
        ))}
        <span className="helper">Step {step}/5</span>
      </div>

      {step === 1 && (
        <section>
          <h2 style={{ margin: '6px 0' }}>1) 基本情報</h2>

          <div className="field">
            <label>名前 *</label>
            <input
              value={data.name}
              onChange={(e) => setData((d) => ({ ...d, name: e.target.value }))}
              onBlur={() => mark('name')}
              placeholder="例）内田 両星"
            />
            {touched.name && errors.name && <div className="error">{errors.name}</div>}
          </div>

          <div className="field">
            <label>メール *</label>
            <input
              value={data.email}
              onChange={(e) => setData((d) => ({ ...d, email: e.target.value }))}
              onBlur={() => mark('email')}
              placeholder="例）you@example.com"
              inputMode="email"
            />
            {touched.email && errors.email && <div className="error">{errors.email}</div>}
          </div>

          <div className="field">
            <label>電話番号 *</label>
            <input
              value={data.phone}
              onChange={(e) => setData((d) => ({ ...d, phone: e.target.value }))}
              onBlur={() => mark('phone')}
              placeholder="例）090-1234-5678"
              inputMode="tel"
            />
            {touched.phone && errors.phone && <div className="error">{errors.phone}</div>}
          </div>
        </section>
      )}

      {step === 2 && (
        <section>
          <h2 style={{ margin: '6px 0' }}>2) エリア・言語・カテゴリ</h2>

          <div className="field">
            <label>活動エリア（都市） *</label>
            <select
              value={data.city}
              onChange={(e) => setData((d) => ({ ...d, city: e.target.value }))}
              onBlur={() => mark('city')}
            >
              <option value="Tokyo">Tokyo</option>
              <option value="Osaka">Osaka</option>
              <option value="Kyoto">Kyoto</option>
              <option value="Fukuoka">Fukuoka</option>
            </select>
            {touched.city && errors.city && <div className="error">{errors.city}</div>}
          </div>

          <div className="field">
            <label>対応言語 *</label>
            <div className="row">
              {LANG_OPTIONS.map((l) => (
                <label key={l} className="badge" style={{ cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={data.languages.includes(l)}
                    onChange={() => toggleArray('languages', l)}
                  />
                  {l}
                </label>
              ))}
            </div>
            {touched.languages && errors.languages && <div className="error">{errors.languages}</div>}
            <div className="helper">※ 最低1つ選択</div>
          </div>

          <div className="field">
            <label>得意カテゴリ *</label>
            <div className="row">
              {CATEGORY_OPTIONS.map((c) => (
                <label key={c} className="badge" style={{ cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={data.categories.includes(c)}
                    onChange={() => toggleArray('categories', c)}
                  />
                  {c}
                </label>
              ))}
            </div>
            {touched.categories && errors.categories && <div className="error">{errors.categories}</div>}
            <div className="helper">※ 最低1つ選択</div>
          </div>
        </section>
      )}

      {step === 3 && (
        <section>
          <h2 style={{ margin: '6px 0' }}>3) 経験・自己紹介</h2>

          <div className="field">
            <label>経験年数 *</label>
            <select
              value={data.years}
              onChange={(e) => setData((d) => ({ ...d, years: e.target.value }))}
              onBlur={() => mark('years')}
            >
              {['1', '2', '3', '4', '5+'].map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
            {touched.years && errors.years && <div className="error">{errors.years}</div>}
          </div>

          <div className="field">
            <label>自己紹介 *</label>
            <textarea
              value={data.bio}
              onChange={(e) => setData((d) => ({ ...d, bio: e.target.value }))}
              onBlur={() => mark('bio')}
              placeholder="例）東京でフードと文化を中心に案内しています。英語対応OK。..."
              rows={6}
            />
            {touched.bio && errors.bio && <div className="error">{errors.bio}</div>}
            <div className="helper">文字数: {data.bio.trim().length} / 50+</div>
          </div>
        </section>
      )}

      {step === 4 && (
        <section>
          <h2 style={{ margin: '6px 0' }}>4) 料金・稼働日</h2>

          <div className="field">
            <label>時給（円） *</label>
            <input
              value={data.rate}
              onChange={(e) => setData((d) => ({ ...d, rate: e.target.value }))}
              onBlur={() => mark('rate')}
              inputMode="numeric"
              placeholder="例）5000"
            />
            {touched.rate && errors.rate && <div className="error">{errors.rate}</div>}
          </div>

          <div className="field">
            <label>稼働日 *</label>
            <select
              value={data.availability}
              onChange={(e) => setData((d) => ({ ...d, availability: e.target.value }))}
              onBlur={() => mark('availability')}
            >
              <option value="Weekdays">平日</option>
              <option value="Weekends">土日</option>
              <option value="Any">いつでも</option>
            </select>
            {touched.availability && errors.availability && (
              <div className="error">{errors.availability}</div>
            )}
          </div>
        </section>
      )}

      {step === 5 && (
        <section>
          <h2 style={{ margin: '6px 0' }}>5) 確認</h2>
          <p className="p">以下の内容で登録します。OKなら「完了」を押してください。</p>

          <div className="card" style={{ marginTop: 10 }}>
            <div className="row" style={{ justifyContent: 'space-between' }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 18 }}>{data.name}</div>
                <div className="helper">{data.email} / {data.phone}</div>
              </div>
              <div className="badge">{data.city}</div>
            </div>
            <hr style={{ border: 0, borderTop: '1px solid var(--line)', margin: '12px 0' }} />
            <div className="row">
              <div className="badge">Languages: {data.languages.join(', ')}</div>
              <div className="badge">Categories: {data.categories.join(', ')}</div>
              <div className="badge">Experience: {data.years} years</div>
              <div className="badge">Rate: ¥{Number(data.rate).toLocaleString()}/h</div>
              <div className="badge">Availability: {data.availability}</div>
            </div>
            <p className="p" style={{ marginTop: 12, whiteSpace: 'pre-wrap' }}>{data.bio}</p>
          </div>

          <div className="row" style={{ marginTop: 12 }}>
            <button
              className="btn"
              onClick={() => {
                try {
                  sessionStorage.setItem('tourmate_guide_profile', JSON.stringify(data));
                } catch {}
                alert('登録完了（デモ）！');
              }}
            >
              完了
            </button>
            <button className="btn secondary" onClick={reset}>最初から</button>
          </div>

          <p className="helper" style={{ marginTop: 10 }}>
            ※ デモなのでサーバー保存はしていません（sessionStorage に一時保存のみ）。
          </p>
        </section>
      )}

      <div className="row" style={{ justifyContent: 'space-between', marginTop: 16 }}>
        <button className="btn secondary" onClick={back} disabled={step === 1}>
          戻る
        </button>

        {step < 5 && (
          <button className="btn" onClick={next} disabled={!canNext()}>
            次へ
          </button>
        )}
      </div>

      {step < 5 && !canNext() && (
        <p className="error" style={{ marginTop: 10 }}>
          入力が不足しています。必須項目を埋めると「次へ」が押せます。
        </p>
      )}
    </div>
  );
}
