# TourMate Clone (Next.js)

## Run locally

```bash
npm install
npm run dev
```

## Deploy
- Push this repo to GitHub (make sure **package.json** and **app/** are at the repository root)
- Import the repo in Vercel and deploy.

